import socketio
import eventlet

sio = socketio.Server(cors_allowed_origins='*')
app = socketio.WSGIApp(sio)



@sio.event
def connect(sid, environ):
    print('connect ', sid)
    

@sio.event
def videostream(sid,data):
    print('I received a message from zmq server')
    
    #print(data)
    sio.emit('videostream_mobile', {'data': data})
    
eventlet.wsgi.server(eventlet.listen(('68.183.88.216', 5001)), app)	
